########################################################
########################################################

# GUI created by: martinja
# Contact: javier.martinez.samblas@cern.ch

########################################################
########################################################

# COMRAD AND PYQT IMPORTS

from comrad import (CApplication, CLineEdit, CCommandButton, CLabel, CDisplay, PyDMChannelDataSource, CurveData, PointData, PlottingItemData, TimestampMarkerData, TimestampMarkerCollectionData, UpdateSource)
from PyQt5.QtGui import (QIcon, QColor, QGuiApplication, QCursor, QStandardItemModel, QStandardItem, QFont, QBrush)
from PyQt5.QtCore import (QSize, Qt, QRect, QAbstractTableModel, QEventLoop, QCoreApplication)
from PyQt5.QtWidgets import (QTableView, QSizePolicy, QAbstractItemView, QTableWidget, QTableWidgetItem, QAbstractScrollArea, QHeaderView, QScrollArea, QSpacerItem, QPushButton, QGroupBox, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit, QDialog, QFrame, QWidget, QProgressDialog)

# OTHER IMPORTS

import sys
import os
from time import sleep
import pyjapc
from general_utils import createCustomTempDir, getSystemTempDir
import collections
import json
import jpype as jp

########################################################
########################################################

# GLOBALS

TEMP_DIR_NAME = "temp_diamond_blm_expert_gui"
SAVING_PATH = "/user/bdisoft/development/python/gui/deployments-martinja/diamond-blm-expert-gui"
UI_FILENAME = "preview_one_device.ui"

########################################################
########################################################

class TableModel(QAbstractTableModel):

    def __init__(self, data, header_labels, working_modules_boolean = False, errors = []):

        super(TableModel, self).__init__()
        self._data = data
        self._header_labels = header_labels
        self.working_modules_boolean = working_modules_boolean
        self.errors = errors

        return

    def headerData(self, section, orientation, role):

        if role == Qt.DisplayRole:
            if orientation == Qt.Horizontal:
                return self._header_labels[section]

    def data(self, index, role):

        row = index.row()
        col = index.column()

        if role == Qt.TextAlignmentRole:
            return Qt.AlignCenter
        elif role == Qt.DisplayRole:
            value = self._data[row][col]
            return value
        elif role == Qt.ToolTipRole and self.working_modules_boolean and col == 2:
            return self.errors[row]
        elif role == Qt.ForegroundRole and self.working_modules_boolean and self.errors[row] != "-":
            return QBrush(QColor("red"))
        elif role == Qt.BackgroundRole and self.working_modules_boolean and self.errors[row] != "-":
            return QBrush(QColor("#FFE2E2"))

    def rowCount(self, index):

        return len(self._data)

    def columnCount(self, index):

        return len(self._data[0])

########################################################
########################################################

class MyDisplay(CDisplay):

    #----------------------------------------------#

    # function to read the ui file
    def ui_filename(self):

        return UI_FILENAME

    #----------------------------------------------#

    # init function
    def __init__(self, *args, **kwargs):

        # get temp dir
        self.app_temp_dir = os.path.join(getSystemTempDir(), TEMP_DIR_NAME)

        # retrieve the app CApplication variable
        self.app = CApplication.instance()

        # import cern package for handling exceptions
        self.cern = jp.JPackage("cern")

        # retrieve the pyccda json info file
        self.readPyCCDAJsonFile()

        # set the device
        self.current_device = "dBLM.TEST4"
        self.LoadDeviceFromTxtPremain()

        # get the property list
        self.property_list = list(self.pyccda_dictionary[self.current_accelerator][self.current_device]["acquisition"].keys())

        # order the property list
        self.property_list.sort()

        # create japc object
        # self.japc = pyjapc.PyJapc(incaAcceleratorName = None) # use this line when launching the main application
        self.japc = pyjapc.PyJapc() # use this line when launching the module for debugging

        # set japc selector
        self.japc.setSelector("")

        # load the gui, build the widgets and handle the signals
        print("{} - Loading the GUI file...".format(UI_FILENAME))
        super().__init__(*args, **kwargs)
        self.setWindowTitle("BLM DIAMOND SETTINGS")
        print("{} - Building the code-only widgets...".format(UI_FILENAME))
        self.buildCodeWidgets()
        print("{} - Handling signals and slots...".format(UI_FILENAME))
        self.bindWidgets()

        # status bar message
        self.app.main_window.statusBar().showMessage("Preview of {} loaded!".format(self.current_device), 10*1000)
        self.app.main_window.statusBar().repaint()

        # close progress bar
        if True:
            self.progress_dialog.close()

        return

    #----------------------------------------------#

    # function that builds the widgets that weren't initialized using the UI qt designer file
    def buildCodeWidgets(self):

        # init progress bar
        if True:
            self.progress_dialog = QProgressDialog("Opening preview for {}...".format(self.current_device), None, 0, len(self.property_list)-1)
            self.progress_dialog.setAutoClose(False)
            self.progress_dialog.setWindowTitle("Progress")
            self.progress_dialog.setWindowIcon(QIcon(SAVING_PATH + "/icons/diamond_2.png"))
            self.progress_dialog.show()
            self.progress_dialog.repaint()

        # initialize widget dicts
        self.labelDict = {}

        # check if the device works
        if self.current_device in self.working_devices:

            # create gui using pyuic5
            self.frame_general_information = QFrame(self.frame_tables)
            self.frame_general_information.setFrameShape(QFrame.NoFrame)
            self.frame_general_information.setFrameShadow(QFrame.Plain)
            self.frame_general_information.setObjectName("frame_general_information")
            self.verticalLayout_frame_general_information = QVBoxLayout(self.frame_general_information)
            self.verticalLayout_frame_general_information.setSpacing(0)
            self.verticalLayout_frame_general_information.setObjectName("verticalLayout_frame_general_information")
            self.label_general_information = QLabel(self.frame_general_information)
            font = QFont()
            font.setBold(True)
            font.setUnderline(False)
            font.setWeight(75)
            self.label_general_information.setText("General Information")
            self.label_general_information.setFont(font)
            self.label_general_information.setAlignment(Qt.AlignCenter)
            self.label_general_information.setObjectName("label_general_information")
            self.label_general_information.setStyleSheet("background-color: rgb(216, 216, 216);")
            self.label_general_information.setFrameShape(QFrame.StyledPanel)
            self.label_general_information.setFrameShadow(QFrame.Plain)
            self.label_general_information.setMinimumSize(30, 30)
            self.verticalLayout_frame_general_information.addWidget(self.label_general_information)
            self.tableView_general_information = QTableView(self.frame_general_information)
            self.tableView_general_information.setStyleSheet("QTableView{\n"
                                                             "    background-color: rgb(243, 243, 243);\n"
                                                             "    margin-top: 0;\n"
                                                             "}")
            self.tableView_general_information.setFrameShape(QFrame.StyledPanel)
            self.tableView_general_information.setFrameShadow(QFrame.Plain)
            self.tableView_general_information.setDragEnabled(False)
            self.tableView_general_information.setAlternatingRowColors(True)
            self.tableView_general_information.setSelectionMode(QAbstractItemView.NoSelection)
            self.tableView_general_information.setShowGrid(True)
            self.tableView_general_information.setGridStyle(Qt.SolidLine)
            self.tableView_general_information.setObjectName("tableView_general_information")
            self.tableView_general_information.horizontalHeader().setHighlightSections(False)
            self.tableView_general_information.horizontalHeader().setMinimumSectionSize(50)
            self.tableView_general_information.horizontalHeader().setStretchLastSection(True)
            self.tableView_general_information.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
            self.tableView_general_information.verticalHeader().setVisible(False)
            self.tableView_general_information.verticalHeader().setDefaultSectionSize(50)
            self.tableView_general_information.verticalHeader().setHighlightSections(False)
            self.tableView_general_information.verticalHeader().setMinimumSectionSize(25)
            self.verticalLayout_frame_general_information.addWidget(self.tableView_general_information)
            self.horizontalLayout_frame_tables.addWidget(self.frame_general_information)
            self.frame_working_devices = QFrame(self.frame_tables)
            self.frame_working_devices.setFrameShape(QFrame.NoFrame)
            self.frame_working_devices.setFrameShadow(QFrame.Plain)
            self.frame_working_devices.setObjectName("frame_working_devices")
            self.verticalLayout_frame_general_information_2 = QVBoxLayout(self.frame_working_devices)
            self.verticalLayout_frame_general_information_2.setSpacing(0)
            self.verticalLayout_frame_general_information_2.setObjectName("verticalLayout_frame_general_information_2")
            self.label_working_devices = QLabel(self.frame_working_devices)
            font = QFont()
            font.setBold(True)
            font.setUnderline(False)
            font.setWeight(75)
            self.label_working_devices.setText("Working Modes")
            self.label_working_devices.setFont(font)
            self.label_working_devices.setAlignment(Qt.AlignCenter)
            self.label_working_devices.setObjectName("label_working_devices")
            self.label_working_devices.setStyleSheet("background-color: rgb(216, 216, 216);")
            self.label_working_devices.setFrameShape(QFrame.StyledPanel)
            self.label_working_devices.setFrameShadow(QFrame.Plain)
            self.label_working_devices.setMinimumSize(30, 30)
            self.verticalLayout_frame_general_information_2.addWidget(self.label_working_devices)
            self.tableView_working_modules = QTableView(self.frame_working_devices)
            self.tableView_working_modules.setStyleSheet("QTableView{\n"
                                                         "    background-color: rgb(243, 243, 243);\n"
                                                         "    margin-top: 0;\n"
                                                         "}")
            self.tableView_working_modules.setFrameShape(QFrame.StyledPanel)
            self.tableView_working_modules.setFrameShadow(QFrame.Plain)
            self.tableView_working_modules.setDragEnabled(False)
            self.tableView_working_modules.setAlternatingRowColors(True)
            self.tableView_working_modules.setSelectionMode(QAbstractItemView.NoSelection)
            self.tableView_working_modules.setShowGrid(True)
            self.tableView_working_modules.setGridStyle(Qt.SolidLine)
            self.tableView_working_modules.setSortingEnabled(False)
            self.tableView_working_modules.setWordWrap(True)
            self.tableView_working_modules.setCornerButtonEnabled(True)
            self.tableView_working_modules.setObjectName("tableView_working_modules")
            self.tableView_working_modules.horizontalHeader().setHighlightSections(False)
            self.tableView_working_modules.horizontalHeader().setMinimumSectionSize(50)
            self.tableView_working_modules.horizontalHeader().setStretchLastSection(False)
            self.tableView_working_modules.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
            self.tableView_working_modules.verticalHeader().setVisible(False)
            self.tableView_working_modules.verticalHeader().setDefaultSectionSize(50)
            self.tableView_working_modules.verticalHeader().setHighlightSections(False)
            self.tableView_working_modules.verticalHeader().setMinimumSectionSize(25)
            self.verticalLayout_frame_general_information_2.addWidget(self.tableView_working_modules)
            self.horizontalLayout_frame_tables.addWidget(self.frame_working_devices)

            # selectorOverride for GeneralInformation should be empty
            selectorOverride = ""

            # get field values via pyjapc
            field_values = self.japc.getParam("{}/{}".format(self.current_device, "GeneralInformation"), timingSelectorOverride=selectorOverride, getHeader=False, noPyConversion=False)

            # convert all elements to string
            field_values = {k: str(v) if k != "monitorNames" else v for k, v in field_values.items()}

            # if the dict has a monitorNames field, process the string a little bit for the sake of aesthetics
            if "monitorNames" in field_values.keys():
                final_field_value = ""
                new_val = field_values["monitorNames"]
                for i in range(0, len(new_val)):
                    string = new_val[i]
                    if i > 0:
                        final_field_value = final_field_value + ", " + string
                    else:
                        final_field_value = string
                final_field_value = "  {}  ".format(final_field_value)
                field_values["monitorNames"] = final_field_value

            # uppercase MonitorNames
            field_values["MonitorNames"] = field_values.pop("monitorNames")

            # sort the dict
            field_values = collections.OrderedDict(sorted(field_values.items()))

            # convert the dict into a list of lists
            self.general_information_data = list(map(list, field_values.items()))

            # set the header names
            self.general_info_header_labels = ["Fields", "Values"]

            # general information model
            self.model_general_information = TableModel(data = self.general_information_data, header_labels = self.general_info_header_labels)
            self.tableView_general_information.setModel(self.model_general_information)
            self.tableView_general_information.update()
            self.tableView_general_information.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
            for c in range(0, len(self.general_info_header_labels)):
                self.tableView_general_information.setColumnWidth(c, 300)
            self.tableView_general_information.verticalHeader().setSectionResizeMode(QHeaderView.Stretch)
            self.tableView_general_information.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.tableView_general_information.setFocusPolicy(Qt.NoFocus)
            self.tableView_general_information.setSelectionMode(QAbstractItemView.NoSelection)
            self.tableView_general_information.horizontalHeader().setFixedHeight(30)
            self.tableView_general_information.horizontalHeader().setStyleSheet("font-weight:bold; background-color: rgb(210, 210, 210);")
            self.tableView_general_information.show()

            # init the data model list for the working modules table
            self.modules_data = []

            # set the header names
            self.modules_header_labels = ["Modes", "Available", "Error", "Last Timestamp"]

            # store full errors
            self.errors = []

            # selectorOverride for the working modules table has to be a specific selector
            # use an empty selector for LHC devices
            if self.current_accelerator == "LHC":
                selectorOverride = ""
            # use SPS.USER.ALL for SPS devices
            elif self.current_accelerator == "SPS":
                selectorOverride = "SPS.USER.SFTPRO1"
            # use an empty selector for the others
            else:
                selectorOverride = ""

            # counter for the dialog progress bar
            dialog_counter = 0

            # iterate over properties for the working modules table
            for property in self.property_list:

                # skip general information property
                if property == "GeneralInformation":
                    continue

                # update progress bar
                if True:
                    self.progress_dialog.setValue(dialog_counter)
                    self.progress_dialog.repaint()
                    self.app.processEvents(QEventLoop.ExcludeUserInputEvents)

                # get first element to speed it up
                # if self.pyccda_dictionary[self.current_accelerator][self.current_device]["acquisition"][property]["scalar"]:
                #     field_to_be_checked = list(self.pyccda_dictionary[self.current_accelerator][self.current_device]["acquisition"][property]["scalar"].keys())[0]
                # elif self.pyccda_dictionary[self.current_accelerator][self.current_device]["acquisition"][property]["array"]:
                #     field_to_be_checked = list(self.pyccda_dictionary[self.current_accelerator][self.current_device]["acquisition"][property]["array"].keys())[0]
                # else:
                #     field_to_be_checked = list(self.pyccda_dictionary[self.current_accelerator][self.current_device]["acquisition"][property]["other"].keys())[0]

                # do a GET request via japc
                try:
                    field_values = self.japc.getParam("{}/{}".format(self.current_device, property), timingSelectorOverride=selectorOverride, getHeader=True, noPyConversion=False)
                    self.modules_data.append([property, "Yes", "-", "{}".format(str(field_values[1]["acqStamp"]))])
                    self.errors.append("-")
                except self.cern.japc.core.ParameterException as xcp:
                    self.modules_data.append([property, "No", str(xcp.getMessage()).split(":")[0], "-"])
                    self.errors.append(str(xcp))

                # update dialog counter
                dialog_counter += 1

            # general information model
            self.model_working_modules = TableModel(data = self.modules_data, header_labels = self.modules_header_labels, working_modules_boolean = True, errors = self.errors)
            self.tableView_working_modules.setModel(self.model_working_modules)
            self.tableView_working_modules.update()
            self.tableView_working_modules.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
            for c in range(0, len(self.modules_header_labels)):
                self.tableView_working_modules.setColumnWidth(c, 150)
            self.tableView_working_modules.horizontalHeader().setStretchLastSection(True)
            self.tableView_working_modules.verticalHeader().setSectionResizeMode(QHeaderView.Stretch)
            self.tableView_working_modules.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.tableView_working_modules.setFocusPolicy(Qt.NoFocus)
            self.tableView_working_modules.setSelectionMode(QAbstractItemView.NoSelection)
            self.tableView_working_modules.horizontalHeader().setFixedHeight(30)
            self.tableView_working_modules.horizontalHeader().setStyleSheet("font-weight:bold; background-color: rgb(210, 210, 210);")
            self.tableView_working_modules.show()

            # enable open button
            self.pushButton_open_device.setEnabled(True)

        # if the device does not work
        else:

            # create gui using pyuic5
            self.frame_not_working = QFrame(self.frame_tables)
            self.frame_not_working.setStyleSheet("QFrame{\n"
                                                 "    background-color: rgb(243, 243, 243);\n"
                                                 "}")
            self.frame_not_working.setFrameShape(QFrame.StyledPanel)
            self.frame_not_working.setFrameShadow(QFrame.Plain)
            self.frame_not_working.setObjectName("frame_not_working")
            self.verticalLayout_frame_not_working = QVBoxLayout(self.frame_not_working)
            self.verticalLayout_frame_not_working.setObjectName("verticalLayout_frame_not_working")
            self.horizontalLayout_frame_tables.addWidget(self.frame_not_working)

            # just show the not working message
            self.labelDict["label_not_working_device"] = QLabel(self.frame_not_working)
            self.labelDict["label_not_working_device"].setObjectName("label_not_working_device")
            self.labelDict["label_not_working_device"].setAlignment(Qt.AlignCenter)
            self.labelDict["label_not_working_device"].setWordWrap(True)
            self.labelDict["label_not_working_device"].setTextFormat(Qt.RichText)
            self.labelDict["label_not_working_device"].setText("<font color=red>NOT WORKING DEVICE - {}</font>".format(self.possible_exception))
            self.labelDict["label_not_working_device"].setStyleSheet("border: 0px solid black; margin: 100px;")
            self.labelDict["label_not_working_device"].setMinimumSize(QSize(120, 32))
            self.verticalLayout_frame_not_working.addWidget(self.labelDict["label_not_working_device"])

            # disable open button
            self.pushButton_open_device.setEnabled(False)

        return

    #----------------------------------------------#

    # function that initializes signal-slot dependencies
    def bindWidgets(self):

        # new device binding
        self.pushButton_open_device.clicked.connect(self.openNewDevice)

        return

    #----------------------------------------------#

    # function that overwrites the txt file so that the premain.py can open the new device panel
    def openNewDevice(self):

        # print the OPEN DEVICE action
        print("{} - Button OPEN DEVICE pressed".format(UI_FILENAME))

        # create the dir in case it does not exist
        if not os.path.exists(os.path.join(self.app_temp_dir, "aux_txts")):
            os.mkdir(os.path.join(self.app_temp_dir, "aux_txts"))

        # write the file
        with open(os.path.join(self.app_temp_dir, "aux_txts", "open_new_device.txt"), "w") as f:
            f.write("True")

        return

    #----------------------------------------------#

    # function that loads the device from the aux txt file
    def LoadDeviceFromTxtPremain(self):

        # load the selected device
        if os.path.exists(os.path.join(self.app_temp_dir, "aux_txts", "current_device_premain.txt")):
            with open(os.path.join(self.app_temp_dir, "aux_txts", "current_device_premain.txt"), "r") as f:
                self.current_device = f.read()

        # load the acc
        if os.path.exists(os.path.join(self.app_temp_dir, "aux_txts", "current_accelerator_premain.txt")):
            with open(os.path.join(self.app_temp_dir, "aux_txts", "current_accelerator_premain.txt"), "r") as f:
                self.current_accelerator = f.read()

        # load the exception if any
        self.possible_exception = ""
        if os.path.exists(os.path.join(self.app_temp_dir, "aux_txts", "exception_premain.txt")):
            with open(os.path.join(self.app_temp_dir, "aux_txts", "exception_premain.txt"), "r") as f:
                self.possible_exception = f.read()

        # load the working devices
        if os.path.exists(os.path.join(self.app_temp_dir, "aux_txts", "working_devices_premain.txt")):
            with open(os.path.join(self.app_temp_dir, "aux_txts", "working_devices_premain.txt"), "r") as f:
                self.working_devices = []
                for line in f:
                    self.working_devices.append(line.strip())

        # load the preloaded devices
        if os.path.exists(os.path.join(self.app_temp_dir, "aux_txts", "preloaded_devices_premain.txt")):
            with open(os.path.join(self.app_temp_dir, "aux_txts", "preloaded_devices_premain.txt"), "r") as f:
                self.preloaded_devices = []
                for line in f:
                    self.preloaded_devices.append(line.strip())

        return

    #----------------------------------------------#

    # function that reads from the json file generated by the pyccda script
    def readPyCCDAJsonFile(self):

        # read pyccda info file
        if os.path.exists(os.path.join(self.app_temp_dir, "aux_jsons", "pyccda_config.json")):
            with open(os.path.join(self.app_temp_dir, "aux_jsons", "pyccda_config.json")) as f:
                self.pyccda_dictionary = json.load(f)

        return

    #----------------------------------------------#

########################################################
########################################################