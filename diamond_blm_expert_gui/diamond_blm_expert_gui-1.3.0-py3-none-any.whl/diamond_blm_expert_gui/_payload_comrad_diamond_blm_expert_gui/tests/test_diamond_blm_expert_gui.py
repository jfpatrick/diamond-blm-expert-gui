"""
High-level tests for the  package.

"""

import diamond_blm_expert_gui


def test_version():
    assert diamond_blm_expert_gui.__version__ is not None
