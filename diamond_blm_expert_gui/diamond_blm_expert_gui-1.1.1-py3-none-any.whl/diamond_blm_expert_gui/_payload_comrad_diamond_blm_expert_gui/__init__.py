"""
Documentation for the diamond_blm_expert_gui package

"""

__version__ = "1.1.1"
